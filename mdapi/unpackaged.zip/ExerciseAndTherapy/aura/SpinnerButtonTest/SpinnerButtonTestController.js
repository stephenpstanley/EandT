({
	dosomething : function(component, event, helper) {
		
	}
})